﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace InfoScan
{
    public class CSVHandler : IDisposable
    {
        #region "Variables"
        private bool _Is_Disposed = false;
        private bool _Is_Initialized = false;

        private string _ErrorText = "";
        protected string _CSV_File;
        protected string _CSV_SourceType;
        protected char _CSV_Seperator;
        protected char _CSV_QuoteChar;
        protected bool _CSV_Header;

        protected bool _CSV_Quoted;
        protected Int32 _Int_ColumnCount = -1;
        protected Int32 _Int_RowColumnCount = -1;
        protected Int32 _Int_CurrentRow = -1;
        protected System.IO.StreamReader _Read_File = null;
        protected List<string> _Al_ColumnList = new List<string>();
        protected Dictionary<string, string> _Col_CurrentRow = new Dictionary<string, string>();

        #endregion

        #region "Const/Dest"

        public CSVHandler(string prmCSVFile, bool prmHeader = true, char prmSeparator = ',', bool prmQuoted = false, char prmQuotedChar = '\"')
        {
            try
            {
                _CSV_SourceType = "FILE";
                _CSV_File = prmCSVFile;
                _CSV_Seperator = prmSeparator;
                _CSV_Header = prmHeader;
                _CSV_Quoted = prmQuoted;
                _CSV_QuoteChar = prmQuotedChar;
                LoadFile(System.IO.File.OpenText(_CSV_File));
            }
            catch (Exception ex)
            {
                _Is_Initialized = false;
                _ErrorText = ex.Message;
            }
        }

        public CSVHandler(System.IO.StreamReader prmStream, bool prmHeader = true, char prmSeparator = ',', bool prmQuoted = false, char prmQuotedChar = '\"')
        {
            _CSV_SourceType = "STREAM";
            _CSV_Seperator = prmSeparator;
            _CSV_Header = prmHeader;
            _CSV_Quoted = prmQuoted;
            _CSV_QuoteChar = prmQuotedChar;
            LoadFile(prmStream);
        }

        ~CSVHandler()
        {
            Dispose();
        }

        public void Dispose()
        {
            if (_Is_Disposed == false)
            {
                _Al_ColumnList.Clear();
                _Al_ColumnList = null;
                _Col_CurrentRow.Clear();
                _Col_CurrentRow = null;

                if ((_Read_File != null))
                {
                    _Read_File.Close();
                    _Read_File.Dispose();
                }

                _Is_Disposed = true;
                GC.SuppressFinalize(this);
            }
        }

        #endregion

        #region "Properties"

        /// <summary>
        /// Returns the number of Columns in file starting from 1.
        /// </summary>
        /// <value></value>
        /// <returns></returns>
        /// <remarks></remarks>
        public Int32 ColumnCount
        {
            get { return (_Int_ColumnCount); }
        }

        public Int32 RowColumnCount
        {
            get { return (_Int_RowColumnCount); }
        }

        public bool IsInitialized
        {
            get { return (_Is_Initialized); }
        }

        /// <summary>
        /// Returns the current error text.
        /// </summary>
        /// <value></value>
        /// <returns></returns>
        /// <remarks></remarks>
        public string ErrorText
        {
            get { return (_ErrorText); }
        }

        /// <summary>
        /// Returns the current row number starting from 1.
        /// </summary>
        /// <value></value>
        /// <returns></returns>
        /// <remarks></remarks>
        public Int32 CurrentRowIndex
        {
            get { return (_Int_CurrentRow + 1); }
        }

        #endregion

        #region "Private Modules"

        private bool LoadFile(System.IO.StreamReader prmStream)
        {
            string strFirstLine = null;
            _ErrorText = "";
            try
            {
                _Read_File = prmStream;

                if (_CSV_Header == true)
                {
                    strFirstLine = _Read_File.ReadLine().Trim();

                    if (_CSV_Quoted == true)
                    {
                        List<string> strCols = default(List<string>);
                        strCols = SplitLine(strFirstLine);
                        _Int_ColumnCount = strCols.Count;
                        for (Int32 i = 0; i <= _Int_ColumnCount - 1; i++)
                        {
                            _Al_ColumnList.Add(strCols[i]);
                        }
                    }
                    else
                    {
                        string[] str = null;
                        str = strFirstLine.Split(_CSV_Seperator);
                        _Int_ColumnCount = str.Length;
                        for (Int32 i = 0; i <= _Int_ColumnCount - 1; i++)
                        {
                            _Al_ColumnList.Add(str[i]);
                        }
                    }
                }
                else
                {
                    strFirstLine = _Read_File.ReadLine().Trim();
                    _Read_File.BaseStream.Seek(0, System.IO.SeekOrigin.Begin);
                    _Read_File.DiscardBufferedData();

                    if (_CSV_Quoted == true)
                    {
                        List<string> strCols = default(List<string>);
                        strCols = SplitLine(strFirstLine);
                        _Int_ColumnCount = strCols.Count;
                    }
                    else
                    {
                        string[] str = null;
                        str = strFirstLine.Split(_CSV_Seperator);
                        _Int_ColumnCount = str.Length;
                    }

                    for (Int32 i = 0; i <= _Int_ColumnCount - 1; i++)
                    {
                        _Al_ColumnList.Add("COL" + i);
                    }
                }
                _Is_Initialized = true;
            }
            catch (Exception ex)
            {
                _Is_Initialized = false;
                _ErrorText = ex.Message;
            }

            return _Is_Initialized;
        }

        private List<string> SplitLine(string strLine)
        {
            Int32 currentPos = 1;
            Int32 FindIndex = 0;
            List<string> strCols = new List<string>();
            while (true)
            {
                FindIndex = strLine.IndexOf(_CSV_QuoteChar.ToString() + _CSV_Seperator.ToString() + _CSV_QuoteChar.ToString(), currentPos);
                if (FindIndex <= 0)
                {
                    FindIndex = strLine.IndexOf(_CSV_QuoteChar, currentPos);
                    if (FindIndex <= 0)
                    {
                        break; // TODO: might not be correct. Was : Exit While
                    }
                }
                strCols.Add(strLine.Substring(currentPos, FindIndex - currentPos));
                currentPos = FindIndex + 3;
                if (currentPos > strLine.Length)
                {
                    break; // TODO: might not be correct. Was : Exit While
                }
            }
            return strCols;
        }

        #endregion

        #region "Public Modules"

        /// <summary>
        /// Moves pointer to the next record in the file.
        /// </summary>
        /// <returns></returns>
        /// <remarks></remarks>
        public bool ReadNext()
        {
            bool functionReturnValue = false;
            _ErrorText = "";
            try
            {
                _Int_RowColumnCount = -1;
                if (_Read_File.Peek() != -1)
                {
                    _Int_CurrentRow += 1;
                    _Col_CurrentRow.Clear();
                    if (_CSV_Quoted == true)
                    {
                        List<string> strCols = default(List<string>);
                        strCols = SplitLine(_Read_File.ReadLine().Trim());
                        _Int_RowColumnCount = strCols.Count;
                        for (Int32 i = 0; i <= _Int_ColumnCount - 1; i++)
                        {
                            if (i < strCols.Count)
                            {
                                _Col_CurrentRow.Add(_Al_ColumnList[i], strCols[i]);
                            }
                            else
                            {
                                _Col_CurrentRow.Add("REFCOL" + i.ToString(), _Al_ColumnList[i]);
                            }
                        }
                    }
                    else
                    {
                        string[] SplitedLine = null;
                        SplitedLine = _Read_File.ReadLine().Trim().Split(_CSV_Seperator);
                        _Int_RowColumnCount = SplitedLine.Length;
                        for (Int32 i = 0; i <= _Int_ColumnCount - 1; i++)
                        {
                            if (i < SplitedLine.Length)
                            {
                                _Col_CurrentRow.Add(_Al_ColumnList[i], SplitedLine[i]);
                            }
                            else
                            {
                                _Col_CurrentRow.Add("REFCOL" + i.ToString(), "");
                            }
                        }
                    }
                    functionReturnValue = true;
                }
            }
            catch (Exception ex)
            {
                _ErrorText = ex.Message;
            }
            return functionReturnValue;
        }

        /// <summary>
        /// Returns value in the Column Name provided. If non existent column is provided NOTHING is returned.
        /// </summary>
        /// <param name="prmColumnName"></param>
        /// <returns></returns>
        /// <remarks></remarks>
        public string GetValue(string prmColumnName)
        {
            string functionReturnValue = null;
            _ErrorText = "";
            try
            {
                if (!_Col_CurrentRow.TryGetValue(prmColumnName, out functionReturnValue))
                {
                    functionReturnValue = null;
                }
            }
            catch (Exception ex)
            {
                _ErrorText = ex.Message;
            }
            return functionReturnValue;
        }


        /// <summary>
        /// Returns value in the Column Index provided. If non existent index is provided NOTHING is returned.
        /// </summary>
        /// <param name="prmColumnIndex">Column Index starts from 1</param>
        /// <returns></returns>
        /// <remarks></remarks>
        public string GetValue(Int32 prmColumnIndex)
        {
            string functionReturnValue = null;
            _ErrorText = "";
            try
            {
                if (prmColumnIndex > 0 && prmColumnIndex <= _Col_CurrentRow.Count)
                {
                    functionReturnValue = _Col_CurrentRow.ElementAt(prmColumnIndex - 1).Value;
                }
                else
                {
                    functionReturnValue = null;
                }
            }
            catch (Exception ex)
            {
                _ErrorText = ex.Message;
            }
            return functionReturnValue;
        }

        /// <summary>
        /// Returns value in the Column Index provided. If non existent index is provided blank is returned.
        /// </summary>
        /// <param name="prmColumnIndex">Column Index starts from 1</param>
        /// <returns></returns>
        /// <remarks></remarks>
        public string GetValueSafe(Int32 prmColumnIndex)
        {
            string functionReturnValue = "";
            _ErrorText = "";
            try
            {
                if (prmColumnIndex > 0 && prmColumnIndex <= _Col_CurrentRow.Count)
                {
                    functionReturnValue = _Col_CurrentRow.ElementAt(prmColumnIndex - 1).Value;
                }
                else
                {
                    functionReturnValue = "";
                }
            }
            catch (Exception ex)
            {
                _ErrorText = ex.Message;
            }
            return functionReturnValue;
        }

        /// <summary>
        /// Returns value in the Column name provided. If non existent name is provided blank is returned.
        /// </summary>
        /// <param name="prmColumnName">Name of the column</param>
        /// <returns></returns>
        /// <remarks></remarks>
        public string GetValueSafe(string prmColumnName)
        {
            string functionReturnValue = "";
            _ErrorText = "";
            try
            {
                if (!_Col_CurrentRow.TryGetValue(prmColumnName, out functionReturnValue))
                {
                    functionReturnValue = "";
                }
            }
            catch (Exception ex)
            {
                _ErrorText = ex.Message;
            }
            return functionReturnValue;
        }

        /// <summary>
        /// Returns string array of columns.
        /// </summary>
        /// <returns></returns>
        /// <remarks></remarks>
        public string[] GetColumns()
        {
            return this._Al_ColumnList.ToArray();
        }

        //=======================================================================================================

        /// <summary>
        /// Checks if given Column Name exists or not.
        /// </summary>
        /// <param name="prmColumnName"></param>
        /// <returns></returns>
        /// <remarks></remarks>
        public bool ColumnExists(string prmColumnName)
        {
            bool functionReturnValue = false;
            _ErrorText = "";
            try
            {
                functionReturnValue = _Al_ColumnList.Contains(prmColumnName);
            }
            catch (Exception ex)
            {
                _ErrorText = ex.Message;
            }
            return functionReturnValue;
        }

        #endregion

    }
}
